import os

os.getcwd()