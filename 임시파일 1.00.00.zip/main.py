

import random
import os

from pico2d import *

RES_DIR = 'image'
canvas_height = 600
canvas_width = 800


# boy 클래스
class Boy:
    def __init__(self):
        # 생성될 위치 값
        self.x = canvas_width // 2
        self.y = canvas_height // 2

        # 이미지 로드
        self.image = load_image(RES_DIR + '/run_animation.png')


        # 애니메이션을 위치 랜덤 값
        self.fidx = random.randint(0,7)

        # 움직임을 표현하기 위함 가속도 값
        self.dx = 0
        self.dy = 0


    def draw(self):
        # 스프라이트의 특정위치에 있는 이미지를 x, y값을 중심으로 하는 그림을 캔버스에 그림
        self.image.clip_draw(100 * self.fidx, 0, 100, 100, self.x, self.y)
        
    
    def update(self):
        # 위치에 가속도 값을 추가
        self.x += self.dx
        self.y += self.dy

        print(self.dx)
        print(self.dy)

        # 애니메이션을 위해 값을 1씩 더함
        self.fidx = (self.fidx + 1) % 8


# grass 클래스
class Grass:
    def __init__(self):
        self.image = load_image(RES_DIR + '/grass.png')

    def draw(self):
        self.image.draw(400,30)

    def update(self):
        pass










# 메인 핸들 이벤트 처리
def handle_events():
    global running

    global boy

    # 이벤트를 받아온다.
    events = get_events()

    # 이벤트 처리
    for e in events:

        # 우상단 종료 버튼을 누를 경우
        if e.type == SDL_QUIT:
            # 종료한다.
            running = False
        
        # 키를 누를 경우
        elif e.type == SDL_KEYDOWN:
            # Esc키를 누를 경우
            if e.key == SDLK_ESCAPE:
                # 종료한다.
                running = False
            elif e.key == SDLK_LEFT:
                boy.dx -= 1
            elif e.key == SDLK_RIGHT:
                boy.dx += 1
            elif e.key == SDLK_UP:
                boy.dy += 1
            elif e.key == SDLK_DOWN:
                boy.dy -= 1
        
        # 키를 눌렀다 땔 경우
        elif e.type == SDL_KEYUP:
            if e.key == SDLK_LEFT:
                boy.dx += 1
            elif e.key == SDLK_RIGHT:
                boy.dx -= 1
            elif e.key == SDLK_UP:
                boy.dy -= 1
            elif e.key == SDLK_DOWN:
                boy.dy += 1


# 초기화 하는 함수
def enter():
    global team
    global boy
    global graww
    boy = Boy()
    grass = Grass()
    team = [ grass, boy ]

# 업데이트 하는 함수
def update():
    for b in team:
        b.update()

# 캔버스에 그리는 함수
def draw():
    for b in team:
        b.draw()

       
# 캔버스를 연다.
open_canvas(canvas_width, canvas_height)

# 초기화
enter()

# 메인 동작 부분
running = True
while running:
    # 이벤트 처리
    handle_events()

    # 로직 처리
    update()

    # 렌더링
    clear_canvas()
    draw()
    update_canvas()

    # 딜레이
    delay(0.01)

# 작동이 끝났으므로 캔버스를 종료한다.
close_canvas()
