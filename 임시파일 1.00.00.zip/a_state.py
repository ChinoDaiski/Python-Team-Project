
def handle_events():
	pass